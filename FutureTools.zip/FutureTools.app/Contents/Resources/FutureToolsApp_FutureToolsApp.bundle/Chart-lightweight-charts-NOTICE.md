# TradingView Lightweight Charts notice

This application bundles `lightweight-charts` version 5.2.1 locally. The bundled license is `Chart-lightweight-charts-LICENSE.txt`. The chart view includes the required TradingView attribution link.

Upstream package: https://www.npmjs.com/package/lightweight-charts/v/5.2.1
