    (() => {
      const PROTOCOL_VERSION = 1;
      const allowedCommands = new Set(['initialize', 'setHistory', 'updateCandle', 'setTheme', 'resize', 'dispose']);
      let chart = null;
      let candleSeries = null;
      let volumeSeries = null;
      let ma10Series = null;
      let ma55Series = null;
      let ma99Series = null;
      let history = [];
      let watermark = null;
      let watermarkPayload = null;
      let watermarkDark = true;
      let currentChartID = null;
      let currentGeneration = null;
      let initialViewportFitEnabled = false;
      let initialViewportFitSize = null;
      let initialViewportFitFrame = null;
      const shanghaiFormatters = {
        year: new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', year: 'numeric' }),
        month: new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', month: '2-digit' }),
        day: new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', month: '2-digit', day: '2-digit' }),
        time: new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }),
        seconds: new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }),
        full: new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })
      };

      function shanghaiTime(time, kind) {
        if (!Number.isFinite(time)) throw new Error(`invalid chart time=${time}`);
        return shanghaiFormatters[kind].format(new Date(time * 1000));
      }

      function emit(type, message, payload = {}) {
        window.webkit.messageHandlers.chartBridge.postMessage({
          protocolVersion: PROTOCOL_VERSION,
          chartID: currentChartID,
          generation: currentGeneration,
          requestID: message.requestID || null,
          type,
          payload
        });
      }

      function fail(message, error, requestID = null, command = null) {
        const text = `${message}: ${error instanceof Error ? error.message : String(error)}`;
        const errorBox = document.getElementById('error');
        errorBox.textContent = text;
        errorBox.style.display = 'block';
        emit('error', { requestID }, { code: 'CHART_JS_ERROR', command, message: text });
      }

      function assertEnvelope(message) {
        if (!message || message.protocolVersion !== PROTOCOL_VERSION) throw new Error('unsupported protocolVersion');
        if (!allowedCommands.has(message.type)) throw new Error(`unsupported command=${message.type}`);
        if (message.type !== 'initialize' && message.chartID !== currentChartID) throw new Error('chartID mismatch');
        if (message.type !== 'initialize' && message.generation !== currentGeneration) throw new Error('generation mismatch');
      }

      function asCandle(value) {
        if (!value || !Number.isFinite(value.time) || !Number.isFinite(value.open) || !Number.isFinite(value.high) || !Number.isFinite(value.low) || !Number.isFinite(value.close)) throw new Error('invalid candle payload');
        return { time: value.time, open: value.open, high: value.high, low: value.low, close: value.close };
      }

      function asVolume(value) {
        if (!value || !Number.isFinite(value.time) || !Number.isFinite(value.value)) throw new Error('invalid volume payload');
        return { time: value.time, value: value.value, color: value.color };
      }

      function requiredText(value, field) {
        if (typeof value !== 'string' || value.trim().length === 0) throw new Error(`invalid watermark field=${field}`);
        return value.trim();
      }

      function watermarkOptions(payload, dark, width) {
        const symbol = requiredText(payload.symbol, 'symbol');
        const market = requiredText(payload.market, 'market');
        const interval = requiredText(payload.interval, 'interval');
        const symbolSize = width < 360 ? 24 : width < 720 ? 38 : 64;
        const detailSize = width < 360 ? 11 : width < 720 ? 13 : 16;
        return {
          horzAlign: 'center',
          vertAlign: 'center',
          lines: [
            {
              text: symbol,
              color: dark ? 'rgba(226, 232, 240, 0.12)' : 'rgba(15, 23, 42, 0.09)',
              fontSize: symbolSize,
              fontFamily: 'SFMono-Regular, Menlo, monospace',
              fontStyle: '700',
              lineHeight: symbolSize * 1.05
            },
            {
              text: `${market} · ${interval}`,
              color: dark ? 'rgba(226, 232, 240, 0.28)' : 'rgba(15, 23, 42, 0.20)',
              fontSize: detailSize,
              fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif',
              fontStyle: '600',
              lineHeight: detailSize * 1.3
            }
          ]
        };
      }

      function updateWatermark() {
        if (!watermark || !watermarkPayload) return;
        const width = document.getElementById('chart').getBoundingClientRect().width;
        watermark.applyOptions(watermarkOptions(watermarkPayload, watermarkDark, width));
      }

      function cancelInitialViewportFit() {
        if (initialViewportFitFrame !== null) cancelAnimationFrame(initialViewportFitFrame);
        initialViewportFitFrame = null;
      }

      function resetInitialViewportFit() {
        cancelInitialViewportFit();
        initialViewportFitEnabled = true;
        initialViewportFitSize = null;
      }

      function lockInitialViewportFit() {
        cancelInitialViewportFit();
        initialViewportFitEnabled = false;
      }

      function scheduleInitialViewportFit(previousSize = null) {
        if (!initialViewportFitEnabled || !chart || history.length === 0 || initialViewportFitFrame !== null) return;
        const root = document.getElementById('chart');
        const rect = root.getBoundingClientRect();
        if (rect.width <= 0 || rect.height <= 0) return;
        const currentSize = `${rect.width}x${rect.height}`;
        if (previousSize === null && currentSize === initialViewportFitSize) return;
        initialViewportFitFrame = requestAnimationFrame(() => {
          initialViewportFitFrame = null;
          if (!initialViewportFitEnabled || !chart || history.length === 0) return;
          const rect = root.getBoundingClientRect();
          if (rect.width <= 0 || rect.height <= 0) return;
          const size = `${rect.width}x${rect.height}`;
          if (size !== previousSize) {
            scheduleInitialViewportFit(size);
            return;
          }
          chart.resize(rect.width, rect.height);
          chart.timeScale().fitContent();
          initialViewportFitSize = size;
        });
      }

      function initialize(message) {
        const payload = message.payload;
        currentChartID = message.chartID;
        currentGeneration = message.generation;
        const root = document.getElementById('chart');
        resetInitialViewportFit();
        if (watermark) watermark.detach();
        if (chart) chart.remove();
        watermark = null;
        chart = null;
        candleSeries = null;
        volumeSeries = null;
        ma10Series = null;
        ma55Series = null;
        ma99Series = null;
        history.length = 0;
        root.replaceChildren();
        const dark = payload.theme !== 'light';
        chart = LightweightCharts.createChart(root, {
          layout: {
            background: { type: 'solid', color: dark ? '#07131d' : '#ffffff' },
            textColor: dark ? '#cbd5e1' : '#1f2937',
            panes: {
              separatorColor: dark ? '#374151' : '#d1d5db',
              separatorHoverColor: dark ? '#4b5563' : '#9ca3af',
              enableResize: true
            }
          },
          grid: { vertLines: { color: dark ? '#102636' : '#e5e7eb' }, horzLines: { color: dark ? '#102636' : '#e5e7eb' } },
          rightPriceScale: { borderColor: '#374151' },
          localization: { timeFormatter: time => shanghaiTime(time, 'full') },
          timeScale: {
            borderColor: '#374151', timeVisible: true, secondsVisible: false,
            tickMarkFormatter: (time, type) => shanghaiTime(time, ['year', 'month', 'day', 'time', 'seconds'][type])
          },
          crosshair: { mode: LightweightCharts.CrosshairMode.Normal }
        });
        candleSeries = chart.addSeries(LightweightCharts.CandlestickSeries, {
          upColor: '#22c55e', downColor: '#ef4444', borderVisible: false,
          wickUpColor: '#22c55e', wickDownColor: '#ef4444'
        });
        volumeSeries = chart.addSeries(LightweightCharts.HistogramSeries, {
          priceFormat: { type: 'volume' }
        }, 1);
        ma10Series = chart.addSeries(LightweightCharts.LineSeries, { color: '#f59e0b', lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
        ma55Series = chart.addSeries(LightweightCharts.LineSeries, { color: '#ef4444', lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
        ma99Series = chart.addSeries(LightweightCharts.LineSeries, { color: '#0b7cff', lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
        const panes = chart.panes();
        if (panes.length !== 2) throw new Error(`expected 2 panes, got ${panes.length}`);
        panes[0].setStretchFactor(3);
        panes[1].setStretchFactor(1);
        watermarkPayload = payload;
        watermarkDark = dark;
        watermark = LightweightCharts.createTextWatermark(panes[0], watermarkOptions(payload, dark, root.getBoundingClientRect().width));
        setHistory(message);
        chart.timeScale().subscribeVisibleTimeRangeChange(range => emit('visibleRangeChanged', message, { range }));
        chart.subscribeClick(() => emit('click', { requestID: null }));
        emit('ready', message, { libraryVersion: '5.2.1' });
      }

      function setHistory(message) {
        const values = (message.payload.history || []).map(asCandle);
        const volume = (message.payload.volume || []).map(asVolume);
        if (volume.length !== values.length) throw new Error('history/volume length mismatch');
        for (let index = 1; index < values.length; index += 1) {
          if (values[index - 1].time >= values[index].time) throw new Error('history is not strictly increasing');
        }
        for (let index = 0; index < values.length; index += 1) {
          if (values[index].time !== volume[index].time) throw new Error('history/volume time mismatch');
        }
        history.length = 0;
        history.push(...values);
        candleSeries.setData(history);
        volumeSeries.setData(volume);
        setMovingAverages();
        scheduleInitialViewportFit();
        emit('ack', message, { command: 'setHistory', count: history.length });
      }

      function updateCandle(message) {
        const candle = asCandle(message.payload.candle);
        const volume = asVolume(message.payload.volume);
        if (candle.time !== volume.time) throw new Error('candle/volume time mismatch');
        const last = history[history.length - 1];
        if (last && candle.time < last.time) throw new Error('update precedes history tail');
        if (last && last.time === candle.time) history[history.length - 1] = candle;
        else history.push(candle);
        candleSeries.update(candle);
        volumeSeries.update(volume);
        updateMovingAverages();
        scheduleInitialViewportFit();
        emit('ack', message, { command: 'updateCandle' });
      }

      function movingAverage(length) {
        if (history.length < length) return [];
        let total = 0;
        const values = [];
        for (let index = 0; index < history.length; index += 1) {
          total += history[index].close;
          if (index >= length) total -= history[index - length].close;
          if (index >= length - 1) values.push({ time: history[index].time, value: total / length });
        }
        return values;
      }

      function setMovingAverages() {
        ma10Series.setData(movingAverage(10));
        ma55Series.setData(movingAverage(55));
        ma99Series.setData(movingAverage(99));
      }

      function updateMovingAverage(series, length) {
        if (history.length < length) return;
        let total = 0;
        for (let index = history.length - length; index < history.length; index += 1) total += history[index].close;
        series.update({ time: history[history.length - 1].time, value: total / length });
      }

      function updateMovingAverages() {
        updateMovingAverage(ma10Series, 10);
        updateMovingAverage(ma55Series, 55);
        updateMovingAverage(ma99Series, 99);
      }

      function setTheme(message) {
        const dark = message.payload.theme !== 'light';
        watermarkDark = dark;
        chart.applyOptions({
          layout: {
            background: { type: 'solid', color: dark ? '#07131d' : '#ffffff' },
            textColor: dark ? '#cbd5e1' : '#1f2937',
            panes: {
              separatorColor: dark ? '#374151' : '#d1d5db',
              separatorHoverColor: dark ? '#4b5563' : '#9ca3af',
              enableResize: true
            }
          },
          grid: { vertLines: { color: dark ? '#102636' : '#e5e7eb' }, horzLines: { color: dark ? '#102636' : '#e5e7eb' } }
        });
        updateWatermark();
        emit('ack', message, { command: 'setTheme' });
      }

      window.__chartBridgeReceive = message => {
        try {
          assertEnvelope(message);
          switch (message.type) {
            case 'initialize': initialize(message); break;
            case 'setHistory': setHistory(message); break;
            case 'updateCandle': updateCandle(message); break;
            case 'setTheme': setTheme(message); break;
            case 'resize': chart.resize(message.payload.width, message.payload.height); scheduleInitialViewportFit(); emit('ack', message, { command: 'resize' }); break;
            case 'dispose': lockInitialViewportFit(); watermark.detach(); watermark = null; watermarkPayload = null; chart.remove(); chart = null; candleSeries = null; volumeSeries = null; ma10Series = null; ma55Series = null; ma99Series = null; history.length = 0; emit('ack', message, { command: 'dispose' }); break;
          }
        } catch (error) {
          const command = message && message.type;
          fail(`bridge command ${command}`, error, message && message.requestID, command);
          throw error;
        }
      };

      new ResizeObserver(entries => {
        const rect = entries[0].contentRect;
        if (chart && rect.width > 0 && rect.height > 0) {
          chart.resize(rect.width, rect.height);
          updateWatermark();
          scheduleInitialViewportFit();
        }
      }).observe(document.getElementById('chart'));
      const chartRoot = document.getElementById('chart');
      ['pointerdown', 'touchstart', 'wheel'].forEach(type => chartRoot.addEventListener(type, lockInitialViewportFit, { capture: true, passive: true }));
      chartRoot.addEventListener('dblclick', event => {
        event.preventDefault();
        event.stopImmediatePropagation();
        emit('doubleClick', { requestID: null });
      }, { capture: true });
      emit('ready', { requestID: null }, { libraryVersion: '5.2.1', phase: 'bootstrap' });
    })();
